using System.Collections;
using System.Data;
using System.Globalization;
namespace qwertz;
class Hangman
{
    string[] words= Array.Empty<string>();
    int[] usedWords = Array.Empty<int>();
    public void LoadWords() {
        words = File.ReadAllLines("words.txt");
    }

    public string ChooseAWord() {
        Random rnd = new Random();
        int random;
        do {
            random = rnd.Next(0, words.Length); 
        } while(usedWords.Contains(random));
        usedWords.Append(random);
        return words[random];
    }   
}