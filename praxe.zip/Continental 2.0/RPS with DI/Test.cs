using NUnit.Framework;
namespace qwertz;

public class Test {
    public void RockBeatsScissors() {
        GameManager gameManager = new GameManager(new ForcedPlayer(Choices.ROCK), new ForcedPlayer(Choices.SCISSORS));

        Assert.AreEqual(gameManager.PlayTheGame());
    }
}