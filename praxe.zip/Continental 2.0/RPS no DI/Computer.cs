namespace qwertz;

class Computer {
    public Choices ComputerChoice() {
            Random rnd= new Random();
            int random = rnd.Next(0, 2);
            switch (random) {
                default:
                return Choices.ROCK;
                case 0:
                return Choices.PAPER;
                case 1:
                return Choices.SCISSORS;
            }
        }
}