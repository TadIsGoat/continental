﻿class Program
{
    static void Main(string[] args)
    {
        SetMenu setMenu = new SetMenu();
        MinifigureMenu minifigureMenu = new MinifigureMenu();
        PartMenu partMenu = new PartMenu();

        SetDatabase setDatabase = new SetDatabase();
        MinifigureDatabase minifigureDatabase = new MinifigureDatabase();
        PartDatabase partDatabase = new PartDatabase();


        MainMenu(setMenu, minifigureMenu, partMenu, setDatabase, minifigureDatabase, partDatabase);
    }

    static void MainMenu(SetMenu setMenu, MinifigureMenu minifigureMenu, PartMenu partMenu, SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase)
    {
        Console.Clear();
        Console.Write("Welcome to ");
        Console.BackgroundColor = ConsoleColor.Red;
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("LegoPeas"); //not LegoPeace cuz peace was never an option:33
        Console.BackgroundColor = ConsoleColor.Black;
        Console.ForegroundColor = ConsoleColor.White;
        Console.Write(" - find all your pieces in one place!");
        Console.WriteLine("\nPress any key to continue");
        Console.ReadKey();
        Assist.Loader("");
        while (true)
        {
            Console.WriteLine("Where would you like to go?");
            Console.WriteLine("\n1 - Sets");
            Console.WriteLine("2 - Minifigures");
            Console.WriteLine("3 - Parts");
            Console.WriteLine("4 - Exit");
            Console.Write("\nEnter your choice: ");
            char choice = char.ToLower(Console.ReadKey().KeyChar);

            Console.Clear();
            switch (choice)
            {
                case '1':
                    setMenu.Menu(setDatabase, minifigureDatabase, partDatabase);
                    break;
                case '2':
                    minifigureMenu.Menu(setDatabase, minifigureDatabase, partDatabase);
                    break;
                case '3':
                    partMenu.Menu(setDatabase, minifigureDatabase, partDatabase);
                    break;
                case '4':
                    Assist.Loader("Exiting...");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Try again, you brick head!");
                    Console.WriteLine();
                    break;
            }
        }
    }
}