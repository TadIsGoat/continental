using System.Reflection;
using System.Xml.Serialization;

class SetDatabase {
    public List<Set> sets {get; private set;}

    public SetDatabase() {
        sets = new List<Set>();
    }

    public void AddSet(SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase, Set set) {
        Set newSet = new Set();
        if (set != null) {
            newSet = set;
        } else {
            newSet = new Set();
        }

        PropertyInfo[] properties = typeof(Set).GetProperties();
        foreach (PropertyInfo property in properties) {
            Console.Clear();
            if (property.PropertyType == typeof(List<Minifigure>))
            {
                var list = property.GetValue(newSet) as List<Minifigure>;
                while(true) {
                    Console.WriteLine("How do you want to add minifigures?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from minifigure list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Minifigure newMinifigure = new Minifigure();
                        minifigureDatabase.AddMinifigure(setDatabase, minifigureDatabase, partDatabase, newMinifigure);
                        list.Add(newMinifigure);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from minifigure list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newSet, list);
            } else if (property.PropertyType == typeof(List<Part>)) {
                var list = property.GetValue(newSet) as List<Part>;
                while(true) {
                    Console.WriteLine("How do you want to add parts?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from part list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Part newPart = new Part();
                        partDatabase.AddPart(setDatabase, minifigureDatabase, partDatabase, newPart);
                        list.Add(newPart);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from part list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newSet, list);
            }
            else if (property.Name == "_dimensions")
            {
                var list = property.GetValue(newSet) as List<double>;
                for (int i = 0; i < 3; i++)
                {
                    char dim = i == 0 ? 'X' : i == 1 ? 'Y' : 'Z';
                    Console.Write($"\rEnter {Assist.NameEditor(property.Name, true, true)} {dim} in cm (!skip to skip to next dimension/!quit to skip dimensions): ");
                    string input = Console.ReadLine().Replace(".", ",");
                    if (input == "!quit")
                    {
                        if (i == 0)
                        {
                            list.Add(0);
                            list.Add(0);
                            list.Add(0);
                        } 
                        else if (i == 1)
                        {
                            list.Add(0);
                            list.Add(0);
                        }
                        else if (i == 2)
                        {
                            list.Add(0);
                        }
                        i = 3;
                    }
                    else if (input == "!skip")
                    {
                        list.Add(0);
                    }
                    else
                    {
                        list.Add(double.Parse(input));
                    }
                }
                property.SetValue(newSet, list);
            }
            else if (property.Name == "_releaseYears")
            {
                var list = property.GetValue(newSet) as List<int>;

                Console.Write($"How many {Assist.NameEditor(property.Name, false, true)} do you want to enter? ");
                int repeats = int.Parse(Console.ReadLine());
                for (int i = 0; i < repeats; i++)
                {
                    Console.Write($"\rEnter a year (!skip to skip to next/!quit to skip years of release): ");
                    string input = Console.ReadLine();
                    if (input == "!quit")
                    {
                        i = repeats;
                    }
                    else if (input == "!skip")
                    {
                        list.Add(0);
                    }
                    else if (int.TryParse(input, out int intInput)) {
                        list.Add(intInput);
                    }
                    else
                    {
                        list.Add(999);
                    }
                }
                property.SetValue(newSet, list);
            }
            else
            {
                Console.Write($"\rEnter {Assist.NameEditor(property.Name, false, false)} (!skip to skip): ");
                string input = Console.ReadLine();

                if (input == "!skip")
                {
                    property.SetValue(newSet, "0");
                }
                else
                {
                    property.SetValue(newSet, input);
                }
            }
        }
        sets.Add(newSet);
    }

    public Set GetBySetNumber (string setNumber) {
        return sets.Find(x => x._setNumber == setNumber);
    }

    public void ViewSets() {
        foreach (var set in sets) {
            Console.WriteLine($"Name: {set._setName}");
            Console.WriteLine($"Number: {set._setNumber}");
            Console.WriteLine($"Weight: {set._weight}");
            Console.WriteLine($"Instructions: {set._instructions}");
            Console.WriteLine($"Parts:  {set._parts.Count}");
            Console.WriteLine($"Minifigures: {set._minifigures.Count}");
            Console.Write("Release years: ");
            Console.WriteLine(string.Join(", ", set._releaseYears));
            Console.WriteLine($"\nDimensions: {set._dimensions[0]} * {set._dimensions[1]} * {set._dimensions[2]} cm");
        }
        Console.WriteLine();
        Console.WriteLine("Press any to exit");
        Console.ReadKey();
        Assist.Loader("");
    }
}