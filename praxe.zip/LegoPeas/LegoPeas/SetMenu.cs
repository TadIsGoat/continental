class SetMenu {
    public void Menu(SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase)
    {
        while (true) {
            Console.WriteLine("Lego set menu: ");
            Console.WriteLine("\n1 - Add new set");
            Console.WriteLine("2 - View set list");
            Console.WriteLine("3 - Back to main menu");
            Console.Write("\nEnter your choice: ");
            char choice = char.ToLower(Console.ReadKey().KeyChar);
            switch (choice) {
                case '1':
                    setDatabase.AddSet(setDatabase, minifigureDatabase, partDatabase, null);
                    break;
                case '2':
                    Assist.Loader("");
                    setDatabase.ViewSets();
                    break;
                case '3':
                    Assist.Loader("Exiting sets...");
                    return;
                default:
                    Console.WriteLine("Try again, you brick head!");
                    Console.WriteLine();
                    break;
            }
        }
    }
}