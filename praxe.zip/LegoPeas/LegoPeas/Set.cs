class Set {
    public string _setName { get; set; }
    public string _setNumber { get; set; }
    public string _instructions { get; set; }
    public string _weight { get; set; }
    public List<int> _releaseYears { get; set; }
    public List<double> _dimensions { get; set; }
    public List<Part> _parts { get; set; }
    public List<Minifigure> _minifigures { get; set; }


    public Set()
    {
        _parts = new List<Part>();
        _minifigures = new List<Minifigure>();
        _releaseYears = new List<int>();
        _dimensions = new List<double>();
        _dimensions.Capacity = 3;
    }
}