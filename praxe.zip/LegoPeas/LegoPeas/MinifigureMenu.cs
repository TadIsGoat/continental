using System;
using System.Collections.Generic;
using System.Reflection;

class MinifigureMenu
{
    public void Menu(SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase)
    {
        while (true)
        {
            Console.WriteLine("Lego Minifigure menu:");
            Console.WriteLine("\n1 - Add new minifigure");
            Console.WriteLine("2 - View minifigure list");
            Console.WriteLine("3 - Back to main menu");
            Console.Write("\nEnter your choice: ");
            char choice = char.ToLower(Console.ReadKey().KeyChar);
            switch (choice)
            {
                case '1':
                    minifigureDatabase.AddMinifigure(setDatabase,minifigureDatabase, partDatabase, null);
                    break;
                case '2':
                    Assist.Loader("");
                    minifigureDatabase.ViewMinifigures();
                    break;
                case '3':
                    Assist.Loader("Exiting minifigures...");
                    return;
                default:
                    Console.WriteLine("Try again, you brick head!");
                    Console.WriteLine();
                    break;
            }
        }
    }
}