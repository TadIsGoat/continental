using System.Reflection;

class MinifigureDatabase
{
    public List<Minifigure> minifigures { get; private set; }

    public MinifigureDatabase()
    {
        minifigures = new List<Minifigure>();
    }

    public void AddMinifigure(SetDatabase setDatabase,MinifigureDatabase minifigureDatabase, PartDatabase partDatabase, Minifigure minifigure)
    {
        Minifigure newMinifigure;
        if (minifigure != null) {
            newMinifigure = minifigure;
        } else {
            newMinifigure = new Minifigure();
        }

        PropertyInfo[] properties = typeof(Minifigure).GetProperties();
        foreach (PropertyInfo property in properties)
        {
            Console.Clear();
            if (property.PropertyType == typeof(List<Part>))
            {
                var list = property.GetValue(newMinifigure) as List<Part>;
                while(true) {
                    Console.WriteLine("How do you want to add parts?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from part list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Part newPart = new Part();
                        partDatabase.AddPart(setDatabase, minifigureDatabase, partDatabase, newPart);
                        list.Add(newPart);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from part list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newMinifigure, list);
            } else if (property.PropertyType == typeof(List<Set>)) {
                var list = property.GetValue(newMinifigure) as List<Set>;
                while(true) {
                    Console.WriteLine("How do you want to add sets?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from set list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Set newSet = new Set();
                        setDatabase.AddSet(setDatabase, minifigureDatabase, partDatabase, newSet);
                        list.Add(newSet);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from set list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newMinifigure, list);
            }
            else if (property.Name == "_releaseYears")
            {
                var list = property.GetValue(newMinifigure) as List<int>;

                Console.Write($"How many {Assist.NameEditor(property.Name, false, true)} do you want to enter? ");
                int repeats = int.Parse(Console.ReadLine());
                for (int i = 0; i < repeats; i++)
                {
                    Console.Write($"\rEnter a year (!skip to skip to next/!quit to skip years of release): ");
                    string input = Console.ReadLine();
                    if (input == "!quit")
                    {
                        i = repeats;
                    }
                    else if (input == "!skip")
                    {
                        list.Add(0);
                    }
                    else if (int.TryParse(input, out int intInput))
                    {
                        list.Add(intInput);
                    }
                    else
                    {
                        list.Add(999);
                    }
                }
                property.SetValue(newMinifigure, list);
            }
            else
            {
                Console.Write($"\rEnter {Assist.NameEditor(property.Name, false, false)} (!skip to skip): ");
                string input = Console.ReadLine();

                if (input == "!skip")
                {
                    property.SetValue(newMinifigure, "0");
                }
                else
                {
                    property.SetValue(newMinifigure, input);
                }
            }
        }
        minifigures.Add(newMinifigure);
    }

    public Minifigure GetByMinifigureNumber(string minifigureId)
    {
        return minifigures.Find(x => x._minifigureNumber == minifigureId);
    }

    public void ViewMinifigures()
    {
        foreach (var minifigure in minifigures)
        {
            Console.WriteLine($"Name: {minifigure._minifigureName}");
            Console.WriteLine($"Number: {minifigure._minifigureNumber}");
            Console.WriteLine($"Weight: {minifigure._weight}");
            Console.Write("Release years: ");
            Console.WriteLine(string.Join(", ", minifigure._releaseYears));
        }
        Console.WriteLine();
        Console.WriteLine("Press any key to exit");
        Console.ReadKey();
        Assist.Loader("");
    }
}