﻿internal static class Assist
{
    internal static void Loader(string msg)
    { //absolutně useless a contraproductive, ale chtěl jsem to zkusit
        msg = msg == "" ? "Fetching bricks..." : msg;
        Console.Clear();
        Console.WriteLine($"{msg}".PadLeft(30));
        for (int i = 1; i < 51; i++)
        {
            Console.Write($"\r{new string('█', i).PadRight(50, '░')}");
            if (i % 17 == 0)
            {
                Thread.Sleep(100);
            }
            else if (i == 49)
            {
                Thread.Sleep(500);
            }
            else
            {
                Thread.Sleep(5);
            }
        }
        Console.Clear();
    }

    internal static string NameEditor(string toEdit, bool deleteTheS, bool allLowercase)
    {
        char[] toEditArray = toEdit.Replace("_", "").ToCharArray();
        string result = "";
        for (int i = 0; i < toEditArray.Length; i++)
        {
            char currentChar = toEditArray[i];
            if (i == 0)
            {
                result += char.ToUpper(currentChar);
            }
            else if (i == toEditArray.Length - 1 && currentChar == 's' && deleteTheS == true)
            {
                result += "";
            }
            else if (char.IsUpper(currentChar))
            {
                result += " " + currentChar;
            }
            else
            {
                result += currentChar;
            }
        }
        if (allLowercase) {
            result = result.ToLower();
        }
        return result;
    }

    internal static void DisplayAllColors() {
        foreach (var color in Enum.GetNames(typeof(PartColors)))
        {
            Console.WriteLine(color);
        }
    }
}

internal enum PartColors
{
    // Basic Colors
    White,
    LightBluishGray,
    DarkBluishGray,
    Black,
    Red,
    Blue,
    Yellow,
    Green,
    Orange,
    ReddishBrown,
    LightBrown, // Tan
    DarkBrown,
    LightGreen,
    DarkGreen,
    BrightLightOrange,
    DarkRed,
    DarkBlue,
    MediumBlue,
    SandGreen,
    OliveGreen,
    BrightLightBlue,
    BrightLightYellow,

    // Transparent Colors
    TransparentClear,
    TransparentRed,
    TransparentBlue,
    TransparentYellow,
    TransparentGreen,
    TransparentOrange,
    TransparentLightBlue,
    TransparentPink,
    TransparentBlack, // Smoke
    TransparentPurple,
    TransparentBrightGreen,

    // Metallic and Pearl Colors
    MetallicSilver,
    MetallicGold,
    PearlGold,
    PearlSilver,
    PearlDarkGray,
    PearlLightGray,
    Copper,
    ChromeGold,
    ChromeSilver,

    // Other Special Colors
    SandBlue,
    SandRed,
    SandYellow, // Dark Tan
    MaerskBlue,
    MediumLavender,
    DarkPurple,
    LightPurple,
    Magenta,
    LightPink,
    Coral,
    Lime,
    MediumNougat,
    DarkOrange
}