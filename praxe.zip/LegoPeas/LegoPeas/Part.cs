class Part
{
    public string _partName { get; set; }
    public string _partNumber { get; set; }
    public List<int> _releaseYears { get; set; }
    public List<PartColors> _colors { get; set; }
    public string _weight { get; set; }
    public List<double> _dimensions { get; set; }
    public List<Set> _appearsInSets { get; set; }
    public List<Minifigure> _appearsInMinifigures { get; set; }

    public Part()
    {
        _releaseYears = new List<int>();
        _colors = new List<PartColors>();
        _dimensions = new List<double>();
        _appearsInSets = new List<Set>();
        _appearsInMinifigures = new List<Minifigure>();
        _dimensions.Capacity = 3;
    }
}