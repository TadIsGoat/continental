class Minifigure
{
    public string _minifigureName { get; set; }
    public string _minifigureNumber { get; set; }
    public string _weight { get; set; }
    public List<int> _releaseYears { get; set; }
    public List<Part> _parts { get; set; }
    public List<Set> _appearsIn { get; set; }


    public Minifigure()
    {
        _releaseYears = new List<int>();
        _parts = new List<Part>();
        _appearsIn = new List<Set>();
    }
}