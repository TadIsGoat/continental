using System.Reflection;

class PartDatabase
{
    public List<Part> parts { get; private set; }

    public PartDatabase()
    {
        parts = new List<Part>();
    }

    public void AddPart(SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase, Part part)
    {
        Part newPart;
        if (part != null) {
            newPart = part;
        } else {
            newPart = new Part();
        }

        PropertyInfo[] properties = typeof(Part).GetProperties();
        foreach (PropertyInfo property in properties)
        {
            Console.Clear();

            if (property.PropertyType == typeof(List<Set>))
            {
                var list = property.GetValue(newPart) as List<Set>;
                while(true) {
                    Console.WriteLine("How do you want to add sets?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from set list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Set newSet = new Set();
                        setDatabase.AddSet(setDatabase, minifigureDatabase, partDatabase, newSet);
                        list.Add(newSet);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from set list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newPart, list);
            } else if (property.PropertyType == typeof(List<Minifigure>)) {
                var list = property.GetValue(newPart) as List<Minifigure>;
                while(true) {
                    Console.WriteLine("How do you want to add minifigures?");
                    Console.WriteLine("\n1 - Manually");
                    Console.WriteLine("2 - Choose from minifigure list");
                    Console.WriteLine("3 - Upload a file");
                    Console.Write("\nEnter your choice (!skip to skip to next): ");
                    string choice = Console.ReadLine();
                    if (choice == "!skip") {
                        break;
                    } else if (choice == "1") {
                        Minifigure newMinifigure = new Minifigure();
                        minifigureDatabase.AddMinifigure(setDatabase, minifigureDatabase, partDatabase, newMinifigure);
                        list.Add(newMinifigure);
                    } else if (choice == "2") {
                        Console.Clear();
                        Console.WriteLine("Choosing from minifigure list not avaible, please choose other");
                        Console.WriteLine();
                    } else if (choice == "3") {
                        Console.Clear();
                        Console.WriteLine("Uploading not avaible, please choose other");
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Try again, you brickhead!");
                    }
                }
                property.SetValue(newPart, list);
            }
            else if (property.PropertyType == typeof(List<PartColors>)) 
            {
                var list = property.GetValue(newPart) as List<PartColors>;

                while (true) {
                    Console.Write($"Enter {Assist.NameEditor(property.Name, false, true)} (!colors to show all colors/!quit to go to next): ");
                    string input = Console.ReadLine();
                    if (input == "!quit") {
                        break;
                    } else if (input == "!colors") {
                        Console.Clear();
                        Assist.DisplayAllColors();
                        Console.WriteLine("");
                    } else if (Enum.TryParse(typeof(PartColors), input, true, out var result)) {
                        list.Add((PartColors)result);
                    } else {
                        Console.WriteLine("Invalid color, try again, brickhead!");
                    }
                }
                property.SetValue(newPart, list);
            }
            else if (property.Name == "_releaseYears")
            {
                var list = property.GetValue(newPart) as List<int>;

                Console.Write($"How many {Assist.NameEditor(property.Name, false, true)} do you want to enter? ");
                int repeats = int.Parse(Console.ReadLine());

                for (int i = 0; i < repeats; i++)
                {
                    Console.Write($"\rEnter year (!skip to skip to next/!quit to skip all): ");
                    string input = Console.ReadLine();

                    if (input == "!quit")
                    {
                        i = repeats;
                    }
                    else if (input == "!skip")
                    {
                        list.Add(0);
                    }
                    else if (int.TryParse(input, out int intInput))
                    {
                        list.Add(intInput);
                    }
                    else
                    {
                        list.Add(999);
                    }
                }
                property.SetValue(newPart, list);
            }
            else if (property.Name == "_dimensions")
            {
                var list = property.GetValue(newPart) as List<double>;
                for (int i = 0; i < 3; i++)
                {
                    char dim = i == 0 ? 'X' : i == 1 ? 'Y' : 'Z';
                    Console.Write($"\rEnter {Assist.NameEditor(property.Name, true, true)} {dim} in studs (!skip to skip to next dimension/!quit to skip dimensions): ");
                    string input = Console.ReadLine().Replace(".", ",");

                    if (input == "!quit")
                    {
                        if (i == 0)
                        {
                            list.Add(0);
                            list.Add(0);
                            list.Add(0);
                        }
                        else if (i == 1)
                        {
                            list.Add(0);
                            list.Add(0);
                        }
                        else if (i == 2)
                        {
                            list.Add(0);
                        }
                        i = 3;
                    }
                    else if (input == "!skip")
                    {
                        list.Add(0);
                    }
                    else
                    {
                        list.Add(double.Parse(input));
                    }
                }
                property.SetValue(newPart, list);
            }
            else
            {
                Console.Write($"\rEnter {Assist.NameEditor(property.Name, false, false)} (!skip to skip): ");
                string input = Console.ReadLine();

                if (input == "!skip")
                {
                    property.SetValue(newPart, "0");
                }
                else
                {
                    property.SetValue(newPart, input);
                }
            }
        }
        parts.Add(newPart);
    }

    public Part GetByPartNumber(string partNumber)
    {
        return parts.Find(x => x._partNumber == partNumber);
    }

    public void ViewParts()
    {
        foreach (var part in parts)
        {
            Console.WriteLine($"Name: {part._partName}");
            Console.WriteLine($"Number: {part._partNumber}");
            Console.WriteLine($"Weight: {part._weight}");
            Console.WriteLine($"Appears in sets: {part._appearsInSets.Count}");
            Console.WriteLine($"Appears in minifigures: {part._appearsInMinifigures.Count}");
            Console.Write("Release years: ");
            Console.WriteLine(string.Join(", ", part._releaseYears));
            Console.Write("Colors: ");
            Console.WriteLine(string.Join(", ", part._colors));
            Console.WriteLine($"Dimensions: {part._dimensions[0]} * {part._dimensions[1]} * {part._dimensions[2]} cm");
        }
        Console.WriteLine();
        Console.WriteLine("Press any key to exit");
        Console.ReadKey();
        Assist.Loader("");
    }
}