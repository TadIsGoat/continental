using System;
using System.Collections.Generic;
using System.Reflection;

class PartMenu
{
    public void Menu(SetDatabase setDatabase, MinifigureDatabase minifigureDatabase, PartDatabase partDatabase)
    {
        while (true)
        {
            Console.WriteLine("Lego Part menu:");
            Console.WriteLine("\n1 - Add new part");
            Console.WriteLine("2 - View part list");
            Console.WriteLine("3 - Back to main menu");
            Console.Write("\nEnter your choice: ");
            char choice = char.ToLower(Console.ReadKey().KeyChar);
            switch (choice)
            {
                case '1':
                    partDatabase.AddPart(setDatabase, minifigureDatabase, partDatabase, null);
                    break;
                case '2':
                    Assist.Loader("");
                    partDatabase.ViewParts();
                    break;
                case '3':
                    Assist.Loader("Exiting parts...");
                    return;
                default:
                    Console.WriteLine("Try again, you brick head!");
                    Console.WriteLine();
                    break;
            }
        }
    }
}