namespace qwertz;

public class ForcedPlayer : IPlayer {
    private Choices _choices;

    public ForcedPlayer(Choices choice) {
        _choices = choice;
    }

    public Choices PlayerChoice(){
        return _choices;
    }
}