namespace qwertz;

using System.ComponentModel.DataAnnotations;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

class Hangman
{
    Random rnd = new Random();
    string[] words= Array.Empty<string>();
    int[] usedWords = Array.Empty<int>();
    public async void LoadWords(Themes themeToLoadFrom) {
        if (themeToLoadFrom == Themes.generated) {
            words = await WordGen();
        } else {
            words = File.ReadAllLines($"{themeToLoadFrom}.txt");
        }
    }

    public async Task<string> ChooseAWord() {
        int random;
        WordGen().Wait();
        do {
            random = rnd.Next(0, words.Length); 
        } while(usedWords.Contains(random));
        usedWords.Append(random);
        return words[random];
    }

    public async Task<string[]> WordGen() {
        int numOfWords = rnd.Next(1, 2);
        string[] genedWords = new string[numOfWords];
        char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
        char[] consonants = { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z' };

        for (int i = 0; i < numOfWords; i++) {
            int wordLength = rnd.Next(2, 4);
            while (true) {
                string newWord = "";
                for (int j = 0; j < wordLength; j++) {
                    newWord += consonants[rnd.Next(0, consonants.Length)];
                    newWord += vowels[rnd.Next(0, vowels.Length)];
                }
                if (await CheckWordExistence(newWord)) {
                    genedWords[i] = newWord;
                    break;
                }
            }
        }
        return genedWords;
    }

    static async Task<bool> CheckWordExistence(string wordToCheck)
    {
        //wordToCheck = "cat";

        using HttpClient client = new();
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        client.DefaultRequestHeaders.Add("User-Agent", ".NET Word Finder");
        string apiUrl = $"https://api.datamuse.com/words?ml={wordToCheck}&max=1";

        await using Stream stream = await client.GetStreamAsync(apiUrl);
        string rawJson = await client.GetStringAsync(apiUrl);

        Console.WriteLine(apiUrl);
        Console.WriteLine(rawJson);

        /*var gottenWord = await JsonSerializer.DeserializeAsync<Word>(stream);
        if (gottenWord == null) {
            return false;
        } else {
            return true;
        }*/

        if (rawJson == "[]") {
            return false;
        } else {
            return true;
        }
    }
}

/*
public sealed record class Word {
    [JsonPropertyName("word")]
    public required string WordFromApi { get; init; }
}
*/