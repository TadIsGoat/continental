namespace qwertz;

public enum Themes {
    jdm,
    minecraft,
    generated,
}