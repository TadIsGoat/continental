using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

class VideoPlaylistDownloader : Downloader 
{
    private readonly string _playlistUrl;
    private int videoNumber;
    public VideoPlaylistDownloader(string videoUrl)
    {
        _playlistUrl = videoUrl;
    }

    public override async Task DownloadAsync()
    {
        var playlist = await client.Playlists.GetAsync(_playlistUrl);
        string playlistFolderPath = FileAssist.GetFolderPath("downloads", playlist.Title);
        var videos = client.Playlists.GetVideosAsync(playlist.Id);
        Directory.CreateDirectory(playlistFolderPath);

        await foreach (var video in videos) {
            videoNumber++;

            var streamManifest = await client.Videos.Streams.GetManifestAsync(video.Id);
            IStreamInfo streamInfo = streamManifest.GetMuxedStreams().GetWithHighestVideoQuality();
            string filePath = FileAssist.GetFilePath(playlistFolderPath, video.Title, "mp4");

            ReportInfo(video.Title, filePath, playlist.Count, videoNumber, false);
            var progress = new Progress<double>(ReportProgress);

            await client.Videos.Streams.DownloadAsync(streamInfo, filePath, progress);
        }
        ReportInfo(playlist.Title, playlistFolderPath, playlist.Count, videoNumber, true);
    }
}