using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;

abstract class Downloader 
{
    public YoutubeClient client {get;} = new YoutubeClient();
    public abstract Task DownloadAsync();
    internal void ReportInfo(string Title, string filePath, int? totalAmount, int videoNumber, bool allFinished)
    {
        if (!allFinished){
            Console.Clear();
            Console.WriteLine($"Downloading {Title}");
            Console.WriteLine($"{videoNumber}/{totalAmount}: ");
        } else if (allFinished){
            Console.Clear();
            Console.WriteLine($"Finished downloading {videoNumber}/{totalAmount}\nFile name: {Title}\nFile path: {filePath}");
        }
    }
    internal void ReportProgress(double progressValue)
    {
        int filledBlocks = (int)(progressValue * 100); //progressValue is 0.0 to 1.0, u need the whole numbers 0 to 100
        string progressBar = new string('█', filledBlocks).PadRight(100, '░');

        Console.Write($"\r{progressValue:P1} {progressBar}");
        Console.Out.Flush();
    }
}