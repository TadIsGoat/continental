using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;

class AudioDownloader : Downloader
{
    private readonly string _videoUrl;
    public AudioDownloader(string videoUrl)
    {
        _videoUrl = videoUrl;
    }

    public override async Task DownloadAsync()
    {
        var video = await client.Videos.GetAsync(_videoUrl);
        var streamManifest = await client.Videos.Streams.GetManifestAsync(video.Id);
        IStreamInfo streamInfo = streamManifest.GetAudioOnlyStreams().GetWithHighestBitrate();
        string filePath = FileAssist.GetFilePath("downloads", video.Title, "mp3");

        ReportInfo(video.Title, filePath, 1, 1, false);
        var progress = new Progress<double>(ReportProgress);

        await client.Videos.Streams.DownloadAsync(streamInfo, filePath, progress);

        ReportInfo(video.Title, filePath, 1, 1, true);
    }
}