using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

class AudioPlaylistDownloader : Downloader 
{
    private readonly string _playlistUrl;
    private int videoNumber;
    public AudioPlaylistDownloader(string videoUrl)
    {
        _playlistUrl = videoUrl;
    }

    public override async Task DownloadAsync()
    {
        var playlist = await client.Playlists.GetAsync(_playlistUrl);
        string playlistFolderPath = FileAssist.GetFolderPath("downloads", playlist.Title);
        Directory.CreateDirectory(playlistFolderPath);

        var videos = client.Playlists.GetVideosAsync(playlist.Id);

        await foreach (var video in videos) {
            videoNumber++;

            var streamManifest = await client.Videos.Streams.GetManifestAsync(video.Id);
            IStreamInfo streamInfo = streamManifest.GetAudioOnlyStreams().GetWithHighestBitrate();
            string filePath = FileAssist.GetFilePath(playlistFolderPath, video.Title, "mp3");

            ReportInfo(video.Title, filePath, playlist.Count, videoNumber, false);
            var progress = new Progress<double>(ReportProgress);

            await client.Videos.Streams.DownloadAsync(streamInfo, filePath, progress);
        }
        ReportInfo(playlist.Title, playlistFolderPath, playlist.Count, videoNumber, true);
    }
}