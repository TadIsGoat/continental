using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;

public class FileAssist 
{
    public static bool FileValidation(string fileName) {
        if (File.Exists(fileName) && File.ReadAllText(fileName).Contains("https://www.youtube.com")) {
            return true;
        } else {
            return false;
        }
    }
    public static string GetFilePath(string directory, string fileName, string extension)
    {
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), directory, $"{ClearInvalidChars(fileName)}.{extension}");
    }
    public static string GetFolderPath(string folderName, string subFolderName)
    {
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), folderName, ClearInvalidChars(subFolderName));
    }

    private static string ClearInvalidChars(string fileName)
    {
        foreach (char invalidChars in Path.GetInvalidFileNameChars()) {
            fileName = fileName.Replace(invalidChars, '_');
        }
        return fileName;
    }
}