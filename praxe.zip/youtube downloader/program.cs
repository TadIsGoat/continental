﻿using System;
using System.IO;
using System.Threading.Tasks;
using YoutubeExplode;
using YoutubeExplode.Videos.Streams;
using YoutubeExplode.Playlists;
using System.Runtime.CompilerServices;

class Program
{
    static async Task Main(string[] args)
    {
        string format;
        string videoUrl; //can represent a file name
        bool isPlaylist = false;
        bool isFile = false;
        bool isVideo = false;
        while (true) {
            Console.WriteLine("Enter a youtube video URL, youtube playlist URL or a file name:");
            videoUrl = Console.ReadLine();

            if (!videoUrl.Contains("https://www.youtube.com") && (!FileAssist.FileValidation(videoUrl))) {
                Console.WriteLine("Try again!");
            } else { break; }
        }

        while (true) {
            Console.WriteLine("What format do you want? [mp3/mp4]");
            format = Console.ReadLine().ToLower();
            if (format != "mp3" && format != "mp4") {
                Console.WriteLine("That format isn't on the list you bucket head!");
            } else { break; }
        }
        //bitrate/quality ???

        if (videoUrl.Contains("list=")) {
            isPlaylist = true;
        } else if (FileAssist.FileValidation(videoUrl)) {
            isFile = true;
        } else {
            isVideo = true;
        }

        try {
            Downloader downloader;
            if (isPlaylist && format == "mp3") {
                downloader = new AudioPlaylistDownloader(videoUrl);
            } else if (isPlaylist && format == "mp4") {
                downloader = new VideoPlaylistDownloader(videoUrl);
            } else if (isVideo && format == "mp3") {
                downloader = new AudioDownloader(videoUrl);
            } else if (isVideo && format == "mp4") {
                downloader = new VideoDownloader(videoUrl);
            }  else if (isFile) {
                var extractedFile = File.ReadAllLines(videoUrl);
                foreach (var video in extractedFile)
                {
                    if (format == "mp3")
                    {
                        downloader = new AudioDownloader(video);
                    }
                    else
                    {
                        downloader = new VideoDownloader(video);
                    }
                    await downloader.DownloadAsync();
                }
                return;
            } else {
                throw new Exception("Failed to select a downloader");
            }

            if (!isFile) {
                await downloader.DownloadAsync();
            }

        } catch (YoutubeExplode.Exceptions.PlaylistUnavailableException) {
            Console.WriteLine("This playlist is unavaible, probably because it's private");
        } catch (YoutubeExplode.Exceptions.VideoUnavailableException) {
            Console.WriteLine("This video is unavaible, probably because it's private");
        } catch (YoutubeExplode.Exceptions.VideoRequiresPurchaseException) {
            Console.WriteLine("Cannot download videos that require payment");
        } catch (Exception ex) {
            Console.WriteLine("Unexpected error occured: " + ex);
        }
    }
}
