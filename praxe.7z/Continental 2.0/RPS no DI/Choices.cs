namespace qwertz;

public enum Choices
{
    ROCK,
    PAPER,
    SCISSORS
}