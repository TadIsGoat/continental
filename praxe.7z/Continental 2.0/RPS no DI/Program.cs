﻿namespace qwertz;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Rock, Paper, Scissors!");
        Console.ReadKey();
        Load(300, 3);
        GameManager gameManager = new GameManager();
        gameManager.PlayTheGame();
    }

    static void Load(int timer, int repeats) {
        Console.Clear();
        for (int i = 0; i < repeats; i++) {
            for (int j = 0; j < 4; j++) {
                Thread.Sleep(timer);
                Console.Write(".");
            }
            Console.Clear();
        }
        Console.Clear();
    }
}