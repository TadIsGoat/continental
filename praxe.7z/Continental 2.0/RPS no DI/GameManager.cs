namespace qwertz;

class GameManager {
    static Choices playerChoice;
    static Choices computerChoice;
    
    public void PlayTheGame() {
        Round();
        Console.WriteLine("======================");
        Console.WriteLine(WinLoose());
        Console.WriteLine("======================");
        while (true) {
            Console.WriteLine("Wanna play again?[y/n]");
            char dec = char.ToLower(Console.ReadKey().KeyChar);
            if (dec == 'y') {
                PlayTheGame();
                break;
            } else if (dec == 'n') {
                GameEnd();
                break;
            } else {
                Console.Clear();
                Console.WriteLine("\nYou gotta try again...");
            }
        }
    }

    private void Round() {
        Player player = new Player();
        Computer computer= new Computer();

        playerChoice = player.PlayerChoice();
        computerChoice = computer.ComputerChoice();

        Console.Clear();
        Console.WriteLine($"You chose: {playerChoice}");
        Console.WriteLine($"The enemy chose: {computerChoice}");
    }

    private string WinLoose() {
        if (playerChoice == Choices.ROCK && computerChoice == Choices.PAPER ||
            playerChoice == Choices.PAPER && computerChoice == Choices.SCISSORS ||
            playerChoice == Choices.SCISSORS && computerChoice == Choices.ROCK) {
            return "You loose, go next";
        } else if (playerChoice == computerChoice) {
            return "It's a draw, gg";
        } else {
            return "You win, gj";
        }
    }

    private void GameEnd() {
        Console.Clear();
        Console.WriteLine("You coward!");
        Environment.Exit(0);
    }
}