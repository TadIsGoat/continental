namespace qwertz;

class Player {
    public Choices PlayerChoice() {
        while (true) {
            Console.Clear();
            Console.Write("Enter your choice (R)ock, (P)aper, (S)cissors: ");
            string chooseYourPokimon = Console.ReadLine().ToLower();
            if (chooseYourPokimon == "r" || chooseYourPokimon == "rock") {
                return Choices.ROCK;
            } else if (chooseYourPokimon == "p" || chooseYourPokimon == "paper") {
                return Choices.PAPER;
            } else if (chooseYourPokimon == "s" || chooseYourPokimon == "scissors") {
                return Choices.SCISSORS;
            } else {
                Console.WriteLine("Try again idiot!");
                Console.ReadKey();
            }
        }
    }
}