﻿using System.Collections;
namespace qwertz;
class Program
{
    static void Main(string[] args)
    {     
        int top = 101;
        int bot = 0;
        Random rnd = new Random();
        int random = 0;
        
        numGen();
        while (true) {
            Console.WriteLine("Guess the number 0 - 100");
            int guess = int.Parse(Console.ReadLine());

            if (guess < bot || guess > top) {
                Console.WriteLine("Out of range!");
            }
            else if (guess < random) {
                Console.WriteLine("too low!");
            } else if (guess > random) {
                Console.WriteLine("too high!");
            } else {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("You won!");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(500);

                while (true) {
                    Console.WriteLine("\nWanna play again? [y/n]");
                    string decision = Console.ReadLine();
                    if (decision.ToLower() == "y") {
                        numGen();
                        break;
                    } else if (decision.ToLower() == "n") {
                        Environment.Exit(0);
                    } else {
                        Console.WriteLine("skill issue!");
                    }
                }
            }
        }
        void numGen () {
            random = rnd.Next(bot, top);
        }
    }
}