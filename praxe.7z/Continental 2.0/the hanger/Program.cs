﻿using System.Collections;
namespace qwertz;
class Program
{
    static void Main(string[] args)
    {
        while (true) {
            int attempts = 7; 
            char[] alphabet = new char[26];
            for (int i = 0; i < 26; i++)
            {
                alphabet[i] = (char)('a' + i);
            }

            bool win = false;
            Hangman hangman = new Hangman();
            hangman.LoadWords();
            string wordToGuess = hangman.ChooseAWord();
            char[] guessedWord = new string('_', wordToGuess.Length).ToCharArray();
            List<char> usedLetters = new List<char>();

            while (win == false && attempts > 0) {
                DisplayTheGuy(attempts);
                Console.WriteLine($"Attempts remaining: {attempts}");
                Console.WriteLine($"\nWord to guess: {new string(guessedWord)}");
                Console.WriteLine($"Used letters: {string.Join(", ", usedLetters)}");
                Console.Write("Guess a letter: ");
                char guessedLetter = char.ToLower(Console.ReadKey().KeyChar);

                //mimo abecedu
                if (alphabet.Contains(guessedLetter) == false) {
                    Console.WriteLine();
                    Console.WriteLine("Try better dummy!");
                    Thread.Sleep(1000);
                } 
                //opakovane
                else {
                    if (usedLetters.Contains(guessedLetter)) {
                        Console.WriteLine();
                        Console.WriteLine("You have already tried this");
                        Thread.Sleep(1000);
                    }
                    else {
                        usedLetters.Add(guessedLetter);
                        //spravnej guess
                        if (wordToGuess.Contains(guessedLetter)) {
                            for (int i = 0; i < wordToGuess.Length; i++) {
                                if (wordToGuess[i] == guessedLetter)
                                {
                                    guessedWord[i] = guessedLetter;
                                }
                            }
                        }
                        //spatnej guess
                        else {
                            attempts--;
                        }
                        //win
                        if (!new string(guessedWord).Contains('_')) {
                            win = true;
                        }
                    }
                }
                Console.Clear();
            }
            if (attempts <= 0) {
                Console.WriteLine($"You are a hanger! The right word was: {wordToGuess}");
            } else if (win == true) {
                Console.WriteLine("You won, gg ez");
            }
            if (Replay() == false) {
                Environment.Exit(0);
            }
            Console.Clear();
        }
    }
    static bool Replay() {
        while (true) {
            Console.WriteLine("Wanna go next? [y/n]");
            char dec = char.ToLower(Console.ReadKey().KeyChar);
            if (dec == 'y') {
                return true;
            } else if (dec == 'n') {
                return false;
            } else {
                Console.WriteLine("Try again idiot!");
            }
        }
    }

    static void DisplayTheGuy(int attempts) {
        if (attempts == 7)
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("█████████████");
        }
        if (attempts == 6)
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 5)
        {
            Console.WriteLine();
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 4)
        {
            Console.WriteLine("   ╔═════╗");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 3)
        {
            Console.WriteLine("   ╔═════╗");
            Console.WriteLine("   ║     │");
            Console.WriteLine("   ║     @");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 2)
        {
            Console.WriteLine("   ╔═════╗");
            Console.WriteLine("   ║     │");
            Console.WriteLine("   ║     @");
            Console.WriteLine("   ║     ┼ ");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 1)
        {
            Console.WriteLine("   ╔═════╗");
            Console.WriteLine("   ║     │");
            Console.WriteLine("   ║     @");
            Console.WriteLine("   ║    ┌┼┐");
            Console.WriteLine("   ║   ");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
        if (attempts == 0)
        {
            Console.WriteLine("   ╔═════╗");
            Console.WriteLine("   ║     │");
            Console.WriteLine("   ║     @");
            Console.WriteLine("   ║    ┌┼┐");
            Console.WriteLine("   ║    ┌┴┐");
            Console.WriteLine("   ║   ");
            Console.WriteLine(" ╔═╩═╗ ");
            Console.WriteLine("█████████████");
        }
    }
}
