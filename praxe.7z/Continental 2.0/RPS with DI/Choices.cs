namespace qwertz;

public enum Choices
{
    ROCK,
    PAPER,
    SCISSORS
}

/*
public enum Outcomes {
    PlayerWins,
    ComputerWins,
    Draw,
}
*/