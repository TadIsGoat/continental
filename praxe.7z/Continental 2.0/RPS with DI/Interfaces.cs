namespace qwertz; 

public interface IPlayer {
    Choices PlayerChoice();
}

public interface IComputer {
    Choices ComputerChoice();
}

public interface IGameManager {
    void PlayTheGame();
}