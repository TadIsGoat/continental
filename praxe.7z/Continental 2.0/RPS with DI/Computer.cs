namespace qwertz;

class Computer : IComputer {
    public string Name { get; private set; }
    public Computer(string name = "Computer") {
        Name = name; 
    }

    public Choices ComputerChoice() {

        Random random = new Random();
        return (Choices)random.Next(0, 3);

        /*
        Random rnd= new Random();
        int random = rnd.Next(0, 2);
        switch (random) {
            default:
            return Choices.ROCK;
            case 0:
            return Choices.PAPER;
            case 1:
            return Choices.SCISSORS;
        }
        */
    }
}