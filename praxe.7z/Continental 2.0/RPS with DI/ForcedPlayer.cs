namespace qwertz;

public class ForcedPlayer : IPlayer, IComputer {
    private Choices _choices;

    public ForcedPlayer(Choices choice) {
        _choices = choice;
    }

    public Choices PlayerChoice(){
        return _choices;
    }

    public Choices ComputerChoice(){
        return _choices;
    }
}